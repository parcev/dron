// Address of the backend (Render). No trailing slash.
// Examples:  "https://fast-track-api.onrender.com"   |   "http://localhost:3000"
// Leave it empty ("") only if the backend also serves this frontend (same address).
window.API_URL = "https://YOUR-SERVICE.onrender.com";
