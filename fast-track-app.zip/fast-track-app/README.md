# Fast Track scoring system

Judges' calculator, live leaderboard, schedule, big-screen timer and admin tools.

```
frontend/   static website  -> GitHub Pages
backend/    Node API        -> Render.com
            database        -> Neon (Postgres)
```

Pages once deployed (`SITE` = your GitHub Pages address, or your own domain):

| Address | What it is |
|---|---|
| `SITE/` | schedule (current match is highlighted and scrolled to the top) |
| `SITE/calculator/` | judges: pick a team, score, submit |
| `SITE/leaderboard/` | live leaderboard |
| `SITE/timer/` | big-screen timer that follows whichever match timer was started |
| `SITE/admin/` | admin: import the schedule from CSV/Excel or generate it from team names |
| `SITE/admin/scores/` | admin: change, add and delete scores |
| `SITE/admin/schedule/` | admin: edit schedule slots |

## 1. Database (Neon)
1. Create a project at neon.tech.
2. Copy the **connection string** (it looks like `postgresql://user:password@ep-....neon.tech/neondb?sslmode=require`).
3. Nothing else: the backend creates its table (`docs`) by itself on first start.

## 2. Backend (Render)
1. Put this whole folder in a GitHub repository.
2. Render: **New > Web Service** (or **New > Blueprint** to use `render.yaml`), pick the repository.
   If you set it up by hand: root directory `backend`, build command `npm install`, start command `npm start`, health check path `/health`.
3. Environment variables:
   - `DATABASE_URL`: the Neon connection string
   - `JUDGE_PIN`: PIN judges type once on their phone (needed to save scores)
   - `ADMIN_PIN`: PIN for admins (schedule changes, deleting scores)
   - `CORS_ORIGIN`: your frontend address, e.g. `https://yourname.github.io` (no path, no trailing slash)
4. Deploy. Open `https://YOUR-SERVICE.onrender.com/health`, it should answer `{"ok":true}`.

The server refuses to start if `DATABASE_URL`, `JUDGE_PIN` or `ADMIN_PIN` is missing; the reason is in the Render logs.

## 3. Frontend (GitHub Pages)
1. Open `frontend/assets/config.js` and set `window.API_URL` to your Render address, e.g. `"https://fast-track-api.onrender.com"`.
2. Commit and push. The included workflow `.github/workflows/pages.yml` publishes the `frontend` folder.
   In the repository: **Settings > Pages > Source: GitHub Actions**.
3. Your site is at `https://yourname.github.io/REPO/`.
   To get `example.com/leaderboard` style addresses, add your own domain under Settings > Pages (then the repository name is no longer part of the address).
   Without a custom domain the pages are `https://yourname.github.io/REPO/leaderboard/` and so on; they work the same.

Don't want two hosts? The backend also serves the `frontend` folder, so with `window.API_URL = ""` the Render address alone is the whole site.

## Using it
- **PINs:** the first time a judge saves a score (or opens a match) the browser asks for the judges' PIN and remembers it. Admin pages ask for the admin PIN when you change something. A wrong PIN is asked for again.
- **Schedule:** go to `/admin/`, drop a CSV (`Time,Mission_Type,Participant_1,Participant_2`) or type team names and generate it, then import.
- **Backup:** open `https://YOUR-SERVICE.onrender.com/api/export` with the header `x-admin-pin: YOUR_ADMIN_PIN` (for example `curl -H "x-admin-pin: ..." URL > backup.json`). Saved scores and the schedule are also in your Neon database.

## Things to know
- A free Render web service goes to sleep after about 15 minutes without requests and needs roughly a minute to wake up. Open any page a few minutes before the event, or use a paid instance.
- Neon can pause an idle database and wake it automatically; the first request after a pause is slower. The backend retries while it wakes.
- Run **one** backend instance only. Live timers and the live feed are kept in that instance's memory.
- Scores and the schedule are stored in Postgres. Timers, "which judge is active" and the big-screen state are live-only: they are not stored and disappear on a restart, which is fine.
- All judges and screens should have correct clocks (the shared timers use a common end time).

## Changing the code
- Styles: `frontend/assets/style.css`. App logic: `frontend/assets/app.js`.
- HTML: edit `frontend/_template.html`, then run `node tools/make-pages.js` to rewrite the seven page files.
- Local test: `cd backend && npm install`, create `.env` from `.env.example` (export those variables), `node server.js`,
  set `window.API_URL = "http://localhost:3000"`, and open `http://localhost:3000/` (the backend serves the frontend).
